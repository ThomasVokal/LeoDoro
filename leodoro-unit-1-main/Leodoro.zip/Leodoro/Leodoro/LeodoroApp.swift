//
//  LeodoroApp.swift
//  Leodoro
//
//  Created by Graski Lukas on 22.09.26.
//

import SwiftUI

@main
struct LeodoroApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
