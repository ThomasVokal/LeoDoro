//
//  ContentView.swift
//  LeoDoro
//
//  Created by Graski Lukas on 22.09.26.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        TabView {
            HomeView()
                .tabItem {
                    Label("Home", systemImage: "house")
                }
            InfoView()
                .tabItem {
                    Label("Info", systemImage: "info")
                }
        }
    }
}
    #Preview {
        ContentView()
    }

